
# Module Spatial.io – Le Maroc en Immersion

Ce module donne accès à une salle immersive sur Spatial.io avec :
- Objets 3D
- Vidéos patrimoniales
- Interactivité complète
- Voix féminine et narration en direct

## Accès
Intégré via un `<iframe>` dans index.html

## Personnalisation
Vous pouvez remplacer le lien dans le fichier HTML par votre propre salle Spatial.io.

GODMODE : ACTIVÉ
