document.addEventListener('DOMContentLoaded', () => {
  console.log("Extensions activées : GOD MODE, Accessibilité Sacrée, Photon Génétique.");
});